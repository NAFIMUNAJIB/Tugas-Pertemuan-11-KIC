<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Menghitung Luas & Keliling Segitiga</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f0f0f0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    .calculator {
      background-color: white;
      border-radius: 5px;
      box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
      padding: 30px;
      width: 300px;
    }
    h1 {
      text-align: center;
      color: #333;
    }
    body {
     background-image: url('img/mtk-mtk.jpg');
     background-repeat: no-repeat; 
     background-size: cover;
     background-position: center;
}
    form {
      margin-top: 30px;
    }
    label {
      display: block;
      margin-bottom: 5px;
      font-size: 14px;
    }
    input[type="text"],
    select {
      width: 100%;
      padding: 5px;
      font-size: 16px;
      border-radius: 3px;
      border: 1px solid #ccc;
    }
    input[type="submit"] {
      background-color: #007BFF;
      color: white;
      padding: 10px;
      border: none;
      border-radius: 3px;
      cursor: pointer;
      margin-top: 20px;
    }
    .result {
      margin-top: 30px;
      text-align: center;
      font-size: 18px;
      font-weight: bold;
    }
  </style>
</head>
<body>
  <div class="calculator">
    <h1>Menghitung Luas & Keliling Segitiga</h1>
    <form method="post" action="">
      <label for="alas">Masukkan Alas:</label>
      <input type="text" id="alas" name="alas" required>
      <label for="tinggi">Masukkan Tinggi:</label>
      <input type="text" id="tinggi" name="tinggi" required>
      <label for="operasi">Pilih Operasi:</label>
      <select name="operasi" id="operasi" required>
        <option value="luas">Luas</option>
        <option value="keliling">Keliling</option>
      </select>
      <input type="submit" name="submit" value="Hitung">
    </form>
    <?php
      if (isset($_POST['submit'])) {
        $alas = floatval($_POST['alas']);
        $tinggi = floatval($_POST['tinggi']);
        $operasi = $_POST['operasi'];

        if ($operasi == "luas") {
          $hasil = 0.5 * $alas * $tinggi;
        } else if ($operasi == "keliling") {
          $sisi_a = $alas;
          $sisi_b = $tinggi;
          $sisi_c = sqrt(pow($sisi_a, 2) + pow($sisi_b, 2));
          $hasil = $sisi_a + $sisi_b + $sisi_c;
        }

        echo '<div class="result">Hasil: ' . $hasil . '</div>';
      }
    ?>
  </div>
</body>
</html>